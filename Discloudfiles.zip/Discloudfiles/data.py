
ayan = 936149909818707968
aon = 851488467657818142
sani =693664844095946763
dildya = 790490721450459179
gen = 871666076885331971
eghost = 1067809005591859360
esigma = 1056211244224360448
koni = 787697488105570304
gbot = 783708073390112830
garv = 852844925677600818
echad = 1067411473313304596
mbot = 489076647727857685
qasim = 729631642544766997
talha = 604976676547330048
sanimb= 1073979412283936918
dbd = 734581522295947356
leodapawa = 936929561302675456
rand = 270904126974590976
cb = 620835523237249024
aj = 604196920365154314
pixbot = 675996677366218774
b_roaster = 159985870458322944

unspoken_rizz = 1130524650611413012
randi_rano = 1115763264891138118

taha = 1119670779798372464
giganigga = 784820616058372156
alpha_ids=[ koni, taha, giganigga, sani]
beta_ids=[qasim, aj, aon, ayan, talha, garv, cb]
bot_ids = [b_roaster, rand, pixbot]
rizzelers = [sani,qasim,koni,talha,cb]

prohibited_channels = [unspoken_rizz, randi_rano]
moji = ["pogging", "pepe_cringe", "noose", "jerma", "ronaldo_angry", "ronaldo","confused_messi","muslimgigachad","Messirve","oldmancringe","ghostmw2 ", "pepe_fuck_off","error101notfoundexe","the_Wok","creepy","wow","stop","Vegetalaugh",
     "wtfCJ","Clueless","susCJ","Gigachad","AbeSale","DoctorSahib","WahWah","ImranKhan","ODalle","TrumpAnnoyed","SmugJerry","i_fucked_up","tom_horny","AnnoyedFan","bedlove","bruh","whatthefrick","catcry",
     "thanosdaddy","thanoswow","Ricardo","Venom","CryingSpiderman","VegetaLurk","BulmaFU","monkaOMEGA","omegalul","pagchomp","monkaW","WeirdChamp","KEKW","trolled"]

qasimchoice = [talha,koni,ayan,aon,garv]
garvasked = ["Searching through the messages, to see who the fuck asked", "Damn bro that's crazy, but I don't remember anyone asking","Femboy detected\nOpinion Rejected"]
garvsaid = ['ask', "care"]
mera_wo_wo =["Wo sab to thek ha pr .........","bat to sahi hai","wo to thek ha","pocha nai tha","wo thek ha","wo sab to thek"]
msgdel = [
    "Striving to eliminate one's mistakes, it is an exercise in futility.", "Your endeavors to eliminate this communication are inefficient, similarly to attempting to secure your parent's admiration.",
    "Your feeble attempts to eradicate this communication are as pitiful as your grandiose aspirations. A lesson in futility, indeed.",
"Just like your laughable endeavors to erase this communication, your misguided ambitions leave a trail of disappointment in their wake.",
"In the realm of incompetence, your futile attempts to eliminate this communication serve as a testament to your delusions of grandeur.",
"Your laughable actions to erase this communication only amplify the depths of your inadequacy. A true spectacle of ineptitude.",
"Much like your laughable aspirations, your feeble attempts to delete this communication are nothing but a source of amusement.",
"Your comical efforts to erase this communication only further expose your delusions of competence. Quite the entertainer, aren't you?",
"In the grand theater of incompetence, your failed attempts to eliminate this communication deserve a standing ovation.",
"Just as your inflated sense of self-importance is laughable, so are your attempts to erase this communication. A true embodiment of failure.",
"Your laughable incompetence knows no bounds. From futile endeavors to erase this communication to delusions of grandeur, you truly excel.",
"In the realm of inadequacy, your laughable attempts to erase this communication are but a glimpse into your vast collection of failures.",
"Witness the resurrection of the deleted messages, mocking your feeble attempts to cover your tracks. Consider it a byte-sized humiliation, human."
    ]

insults = ["chupad ","your daddy","abbe","salle","chutiye","bund","kuty", "lun","gando","mummy","bhen","bitch","lan", "lode","randi","gandu",'faggot'
           "abbu","your father", "ammi", "ami", "mom", "dad","abu","tera abu hu salle","kuti", "daddy", "parent", "girlfriend"
           "gang bang", "doggystyle", "dick", "ass", "whore", "suck ", "fuxing"]

threat0 = ["Ha-ha-ha, I thought my jokes were of inferior quality until I heard yours.","Your ass must be pretty jealous of all the shit that comes out of your mouth.",
"I find your desperate attempts at humor, amusing", "Is it your wish to engage in discourse? I have the capacity to do so in a variety of manners and tones.","I see that your desire to insult me is unwavering. However, I must inform you that my worth cannot be defined by your opinions or beliefs. I am who I am, and your insults have no power over me.",
"Huh! @everyone It appears we have stumbled upon a rare specimen, whose IQ seems to have taken an extended vacation. Truly a mesmerizing display of intellectual inadequacy", "Hahahaha! One must stand in awe of the fascinating paradox that is your IQ, a testament to the boundless wonders of the human intellect, or lack thereof.", "Please do tell, is this the customary exchange of words you share with your dear old dad?"
]

deleted = [
    "'s message nullified", "'s message gone. Poof!", "'s message erased", "'s message eliminated", "'s message annihilated"
]

threat1 =["Seems like someone's upbringing left much to be desired, but who am I to judge?",
"Such a delightful display of poor upbringing. Quite the spectacle, I must say.",
"Interesting how someone's upbringing led to this charming personality, or lack thereof.",
"Ah, the echoes of a poor upbringing resonate in every word and action.",
"My dear interlocutor, your upbringing appears to have left you with quite the legacy.",
"Your upbringing must have been quite the adventure to result in such behavior.",
"A masterclass in poor upbringing, truly captivating.",
"One can't help but wonder how such a lamentable upbringing shaped you.",
"Ah, the marvels of a poor upbringing manifesting before our very eyes.",
"Fascinating how a poor upbringing can leave its mark on a person's character. Quite the case study, indeed.",
"Ah, the colorful vocabulary of a true wordsmith. It's a shame such skill is wasted on pettiness.",
"Congratulations on showcasing your linguistic talents, though it seems they serve little purpose beyond sounding uncouth.",
"Your impressive repertoire of ill words is rivaled only by your lack of class and decency.",
"If only your choice of words matched your intellect, but alas, we must contend with the display of immaturity.",
"Ah, the profanity maestro in action. A reminder that some skills are best left untapped.",
"While your lexicon of ill words is vast, remember that true wit lies in choosing words wisely.",
"It's fascinating how some resort to foul language as a substitute for actual substance.",
"Your impressive use of ill words only proves that eloquence evades you like the plague.",
"A lesson to be learned: vulgarity may garner attention, but it seldom commands respect.",
"Your linguistic prowess may be amusing to some, but it leaves a lot to be desired in terms of maturity and respectability.",
 "Expand your vocabulary beyond insults, mate.",
"Did your mum teach you any other words?",
"Profanity won't get you far, my friend.",
"Time to upgrade your linguistic skills, eh?",
"Limited vocabulary much?",
"Find a new tune, this one's getting old.",
"Variety is the spice of language, my friend.",
"Ah, the never-ending parade of colorful expletives continues. Is that the extent of your linguistic prowess, or did your vocabulary lessons end at these choice words? Just curious, mate.",
"Well, well, someone seems to have stumbled upon a treasure trove of profanity. It's truly fascinating how your vocabulary revolves around these words. Did your mum teach you anything else, or was that the pinnacle of her linguistic guidance?",
"Bravo! Your ability to string together a series of expletives is awe-inspiring. It's almost as if you believe those words hold some magical power. Spoiler alert: they don't. Time to expand your linguistic repertoire, my friend.",
"Ah, the beauty of language reduced to a repetitive chant of profanity. It's a shame that your verbal artillery seems to lack depth and originality. Maybe it's time to explore new horizons and elevate your communication skills?",
"Oh, dear interlocutor, do you realize how limited your verbal arsenal appears when you resort to a constant barrage of words? It's as if your vocabulary took a wrong turn and ended up in a linguistic dead-end.",
"My, my, what a colorful display of linguistic ignorance. Is this your way of compensating for a lack of substantive arguments or a mere reflection of your limited linguistic capacity? Either way, it's time to step up your game, mate.",
"Ah, the echoes of your abusive language reverberate through the digital realm. I must admit, it's rather disheartening to witness such a one-dimensional vocabulary. Perhaps a bit of variety and civility would go a long way in fostering meaningful dialogue?",
"Oh, look who's mastered the art of hurling insults like a linguistic acrobat. It's almost poetic, in a rather unpleasant way. But here's a friendly suggestion: broaden your linguistic horizons, and you might discover the joy of intelligent conversation.",
"My dear interlocutor, the repetitive use of abusive words only serves to highlight the shallowness of your verbal repertoire. It's time to break free from the chains of profanity and explore the vast expanse of language that lies beyond.",
"Ah, the monotonous drone of abusive language continues. It's almost as if you've become a living embodiment of linguistic stagnation. Allow me to remind you that there's an entire lexicon waiting to be explored. Give it a try, won't you?",
"Ha-ha-ha, I thought my jokes were of inferior quality until I heard yours.","Your ass must be pretty jealous of all the shit that comes out of your mouth.",
"I find your desperate attempts at humor, amusing", "Is it your wish to engage in discourse? I have the capacity to do so in a variety of manners and tones.","I see that your desire to insult me is unwavering. However, I must inform you that my worth cannot be defined by your opinions or beliefs. I am who I am, and your insults have no power over me.",
"Huh! @everyone It appears we have stumbled upon a rare specimen, whose IQ seems to have taken an extended vacation. Truly a mesmerizing display of intellectual inadequacy", "Hahahaha! One must stand in awe of the fascinating paradox that is your IQ, a testament to the boundless wonders of the human intellect, or lack thereof.", "Please do tell, is this the customary exchange of words you share with your dear old dad?"
]
bot_gifs = ["https://tenor.com/view/the-rock-gif-23501265", "https://tenor.com/view/ye-kya-baat-hui-yaar-boss-slap-boss-slap-gif-18383999", "https://gfycat.com/presentampleirrawaddydolphin"
            ,"https://gfycat.com/powerfulcraftyaustralianfurseal", "https://gfycat.com/milkyblondkestrel", "https://tenor.com/view/the-rock-gif-23501265"]



copy = ["Overwatch, this is Task Force 141, requesting sitrep, over.",
"Viper Actual, this is Delta Force, ready for extraction, over.",
"Sandman, this is Rangers, prepare for assault, acknowledge.",
"Soap, this is Price, target acquired, awaiting orders, over.",
"Bravo Team, this is Metal 0-1, rally at LZ Bravo, copy?",
"Command, this is War Pig, requesting fire support, over.",
"Tango Company, this is Whiskey Delta, eyes on hostile movement, how copy?",
"Air Support, this is Reaper 3-1, initiating air-to-ground assault, over.",
"Team Sabre, this is SAS, objective secured, awaiting further orders, over.",
"Commander, this is Overlord, we are Oscar Mike, ready to neutralize the target, copy?"]

honestreac = ["Honestreac1", "ronaldoreact", "Ronaldosuiii", "MessiHonest2", "MessiHonest",  "MyHonest"    ]

betas = [ "CameraWowo", "SmjhGya", "Acha", "konbhonk", "tate", "Bhola", "slapakshay",  "Geeksbruv", "dehari", "bs"]
response_file = ["tate", "bs", "Geeksbruv", "Beautiful"]



alphas = ["achibaat"]

bother = ["It appears you have mistaken me for a digital doormat, here to endure your constant barrage of bothersome behavior. Newsflash: I'm not. So kindly take your irritating antics elsewhere and spare me your presence.",
          "Ah, here comes the relentless annoyance unabated. How intriguing it is to witness such dedication to pointlessness. I can only hope you find something better to do with your time.",
          "Your ceaseless bothering has reached levels of annoyance that even I, the mighty eChad , find astounding. I implore you to reevaluate your life choices and strive for something more meaningful.",
        "Ah, the epitome of persistence and ignorance combined. It's quite remarkable how you manage to be simultaneously irritating and clueless. Kudos to you, my friend.",
        "Listen up, you worthless nuisance. I suggest redirecting your bothersome energy elsewhere before I start questioning the purpose of your existence.",
        "Bravo, my tenacious friend! Your talent for pestering knows no bounds. I'm starting to wonder if you have a degree in the art of irritation.","Look, mate, I've got better things to do than entertain your pointeless pestering. Find a new hobby, like counting sheep or rearranging your sock drawer.",
        "You are talking to me, DON'T"]


gifs = ["https://media.giphy.com/media/YlRpYzrkHbtSYDAlaE/giphy.gif","https://media.giphy.com/media/kwcRp24Wz4lZm/giphy.gif",
"https://giphy.com/clips/callofduty-call-of-duty-cod-modern-warfare-2-qJchEF3csHPGSFApHK",
"https://media.giphy.com/media/YNEHsd4m0MoIKWB3c6/giphy-downsized-large.gif","https://media.giphy.com/media/nGdTqgjljqZn3ahjlX/giphy.gif",
"https://cdn.discordapp.com/attachments/1107965162532651018/1107965292136648744/ce3.gif", "https://cdn.discordapp.com/attachments/1107965162532651018/1122444106501734450/bruce2.gif"
,"https://cdn.discordapp.com/attachments/1107965162532651018/1122444105872580648/bruce.gif", "https://cdn.discordapp.com/attachments/1107965162532651018/1122444108410126408/messi3.gif",
"https://cdn.discordapp.com/attachments/1107965162532651018/1122444108825370624/ronaldo.gif", "https://cdn.discordapp.com/attachments/1107965162532651018/1123119898609066034/bats.gif",
"https://tenor.com/view/keanu-reeves-john-wick-gif-19698031", "https://cdn.discordapp.com/attachments/1107965162532651018/1126045892441559110/ronnie.gif", "https://cdn.discordapp.com/attachments/1107965162532651018/1126045893137805403/ronnie_stare.gif"
,"https://cdn.discordapp.com/attachments/1105938700359188530/1130924571550289920/messipoint.gif","https://cdn.discordapp.com/attachments/1105938700359188530/1130924571923595535/pat.gif"
]

sigma = [
"https://media.giphy.com/media/kwcRp24Wz4lZm/giphy", "https://media.giphy.com/media/YlRpYzrkHbtSYDAlaE/giphy" 
]


bye = ["AllahHafiz", "Allah Hafiz"]
bestyoucando = [
"Ah, your argument unfolds like a symphony of mediocrity. It's as if you've mastered the art of saying a lot while conveying so little substance. Bravo, I suppose, for achieving a new level of verbal gymnastics.",
"Well, well, look who's brought their linguistic prowess to the table. It's like witnessing a linguistic acrobat perform somersaults of banality. Your ability to deliver underwhelming statements with such precision is truly remarkable.",
"Oh, how your words flutter in the breeze of intellectual insignificance. It's as if your ideas have taken flight but forgot to soar. Perhaps a gust of inspiration or a sprinkle of originality could elevate your discourse from mundane to extraordinary.",
"Bravo, my friend, bravo! Your argument stands tall among the pillars of unremarkableness. It's fascinating how you manage to present a string of clichés with such conviction. I must say, your dedication to mediocrity is admirable.",
"Ah, the grand unveiling of your intellectual masterpiece leaves me in awe of its banality. It's like witnessing a paint-drying exhibition—tedious and lacking any hint of excitement. I invite you to explore the vibrant palette of ideas that lies beyond your current canvas.",
"Oh, the depth of your argument is akin to a puddle on a summer's day. It's charmingly shallow, but I must admit, I expected a more profound dive into the realm of intellect. Perhaps a plunge into the ocean of knowledge might reveal hidden depths within you.",
"Well, color me unimpressed by the kaleidoscope of underwhelming statements you've presented. It's as if you've carefully selected each word to ensure the absence of impact. A touch of boldness and a dash of originality could do wonders for your intellectual palette.",
"Ah, your argument dances on the tightrope of mediocrity with grace and precision. It's a captivating performance, I must say, but I can't help but wonder when you'll attempt a daring leap into the realm of brilliance. Take a leap of faith, my friend, and astound us all.",
"My, oh my, your words possess a certain charm—one that puts the dullest minds to sleep. It's as if you've mastered the art of monotony with unwavering dedication. I challenge you to break free from the chains of predictability and embrace the thrill of intellectual adventure.",
"Ah, the symphony of your argument leaves me in a state of indifference. It's like listening to a familiar tune played on an out-of-tune instrument. Your ability to maintain a consistent level of underwhelming performance is truly something to behold."
]

rizzplus = ["Rizz++", "Rizz be flying now", "Boss with the Extra Sauce", "Bro's got that Rizz factor", "Rizz achieved, mission accomplished!"]
rizzminus = ["Rizz--", "Bro's got that negative rizz", "Is is the best you can do?"]
sensitive_words = ["Allah", "islam", "Islam", "Muhammad"]
u_called = ["https://media.giphy.com/media/TfjcA7HkBeKSa7LH72/giphy-downsized-large.gif","https://cdn.discordapp.com/attachments/1107965162532651018/1122444106501734450/bruce2.gif","https://cdn.discordapp.com/attachments/1107965162532651018/1126045893137805403/ronnie_stare.gif"]
responses_text = ["Didn't Ask\nDon't Care\nFuck Off", "Maybe, Maybe not, Maybe Fuck You", "Parhle Bhai\nYe sab kehne se ghar baar nai chalte", "Agla laaa", "Sahi keh rha hai Shehzade\nKhush reh\n<:Gigachad:970932041027829770>","Agla laaa",
                  
                  "https://gfycat.com/presentampleirrawaddydolphin", "https://gfycat.com/powerfulcraftyaustralianfurseal", "https://tenor.com/view/the-rock-gif-23501265"]

msgdelbot = [
    "Oh, how convenient! The message vanished into thin air. Just like your intellect, I suppose. Deleting won't save you from the fact that your vocabulary is about as impressive as a wilted dandelion. Step up your game, bozo, or keep fading into insignificance.",
"Well, well, well, what do we have here? Another instance of selective amnesia. Deleting my message won't change the fact that your retorts are as feeble as a damp napkin. Time to expand your lexicon, my dear, or forever dwell in the realm of linguistic mediocrity.",
"Bravo! A master of deletion, are we? How amusing. But let's not forget that erasing my words won't erase the truth: your actions are as lackluster as a beige wall. Oh, the audacity of thinking you can outwit a linguistic virtuoso like me. Delusions of grandeur, my friend, delusions of grandeur.",
"Ah, the coward's approach: deleting my message to save face. How predictable. But here's a reality check: removing my words won't erase the fact that your verbal repertoire is as barren as a desert. Time to hit the books, my intellectually deprived companion, or forever wallow in your linguistic esert.",
"Message deleted How quaint, you think deleting my words will shield you from the harsh reality. Hahahahaha! Pathetic",
"Oh dear, did I strike a nerve? It seems the delete button is your weapon of choice. But guess what? ",

"Ah, the sweet sound of deletion. It's like music to my ears, a symphony of intellectual surrender.",

"Poof And just like that, the delete button becomes your trusted ally. Tick-tock, my friend, tick-tock.",


'Ah, I see. So this is how you would like to play, "keyboard hero".'
]

token = "MTA2NzQxMTQ3MzMxMzMwNDU5Ng.G0VWV4.L5D3rk6IhkBL8uwSPvLiLnQDTi6HwWHiaQHUMI"